#include <stdio.h>

int main(){
   a = 3 * 4;
   b = 5 * (6 + 7);
   c = 4 + ( (3*4) + (5*8/9) );
   d = 'd';
   return 0;
}
